//[app Javascript]


$(function () {
    "use strict";
    
		// donut chart
		$('.donut').peity('donut');
		
		// bar chart
		$(".bar").peity("bar");	
	
  }); // End of use strict